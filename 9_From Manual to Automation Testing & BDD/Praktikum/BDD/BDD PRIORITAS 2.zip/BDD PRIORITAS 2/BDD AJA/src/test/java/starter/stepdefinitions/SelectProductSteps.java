package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.Login;
import starter.login.SelectProduct;

public class SelectProductSteps {
    @Steps
    SelectProduct login;
    @Given("I am logged in to Sepulsa")
    public void LoginSepulsa(){login.LoginSepulsa();}
    @When("I click on the Product menu")
    public void clickProductMenu(){
        login.clickProductMenu();
    }
    @And("I choose a specific product, an example Pulsa")
    public void chooseSpecificProduct(){
        login.chooseSpecificProduct();
    }
    @And("I entered the phone number")
    public void enterPhoneNumber(){
        login.enterPhoneNumber();
    }
    @And("I click on one of the desired number of pulses")
    public void clickDesiredNumberPulses(){
        login.clickDesiredNumberPulses();
    }
    @Then("I should see the product details and options for payment")
    public void seeProductDetails(){
        login.seeProductDetails();
    }
}
