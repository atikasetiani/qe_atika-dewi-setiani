package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.Payment;

public class PaymentSteps {
    @Steps
    Payment login;
    @Given("that I have selected pulse and then looked at the payment details on Sepulsa")
    public void SelectandLookedPaymentDetails(){login.SelectandLookedPaymentDetails();
    }
    @When("I chose and click on one of the payment method")
    public void selectPaymentMethod(){
        login.selectPaymentMethod();
    }
    @And("I click Bayar Sekarang button")
    public void clickBayarSekarang(){
        login.clickBayarSekarang();
    }
    @Then("I will see a confirmation message and a receipt")
    public void seeConfirmationMessage(){
        login.seeConfirmationMessage();
    }
}
