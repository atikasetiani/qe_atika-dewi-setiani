package starter.login;

import net.thucydides.core.annotations.Step;

public class Login {
    @Step("I am on the Sepulsa homepage")
    public void onTheSepulsaPage(){
        System.out.println("I am on the Sepulsa homepage");
    }
    @Step("I click on the Masuk button")
    public void clickMasukButton(){
        System.out.println("I click on the Masuk button");
    }
    @Step("I enter my registered email and password correcly")
    public void enterEmailandPassword(){
        System.out.println("I enter my registered email and password correcly");
    }
    @Step("I click on Masuk button")
    public void clickforMasukButton(){
        System.out.println("I click on Masuk button");
    }
    @Step("I should be redirected to the dashboard Sepulsa page")
    public void onTheSepulsaHomepage(){
        System.out.println("I should be redirected to the dashboard Sepulsa page");
    }
}