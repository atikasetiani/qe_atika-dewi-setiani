package starter.login;
import net.thucydides.core.annotations.Step;
public class SelectProduct {
    @Step("I am logged in to Sepulsa")
    public void LoginSepulsa(){
        System.out.println("I am logged in to Sepulsa");
    }
    @Step("I click on the Product menu")
    public void clickProductMenu(){
        System.out.println("I click on the Product menu");
    }
    @Step("I choose a specific product, an example Pulsa")
    public void chooseSpecificProduct(){
        System.out.println("I choose a specific product, an example Pulsa");
    }
    @Step("I entered the phone number")
    public void enterPhoneNumber(){
        System.out.println("I entered the phone number");
    }
    @Step("I click on one of the desired number of pulses")
    public void clickDesiredNumberPulses(){
        System.out.println("I click on one of the desired number of pulses");
    }
    @Step("I should see the product details and options for payment")
    public void seeProductDetails(){
        System.out.println("I should see the product details and options for payment");
    }
}
