package starter.login;
import net.thucydides.core.annotations.Step;
public class Payment {
    @Step("that I have selected pulse and then looked at the payment details on Sepulsa")
    public void SelectandLookedPaymentDetails(){
        System.out.println("that I have selected pulse and then looked at the payment details on Sepulsa");
    }
    @Step("I chose and click on one of the payment method")
    public void selectPaymentMethod(){
        System.out.println("I chose and click on one of the payment method");
    }
    @Step("I click Bayar Sekarang button")
    public void clickBayarSekarang(){
        System.out.println("I click Bayar Sekarang button");
    }
    @Step("I will see a confirmation message and a receipt")
    public void seeConfirmationMessage(){
        System.out.println("I will see a confirmation message and a receipt");
    }
}
