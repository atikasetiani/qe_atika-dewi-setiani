package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.Profile;

public class ProfileSteps {
    @Steps
    Profile login;
    @Given("I'm already logged in to my LinkedIn account")
    public void onTheLinkedInPage(){
        login.onTheLinkedInPage();
    }
    @When("I clicked on my profile picture")
    public void clickProfilePicture(){
        login.clickProfilePicture();
    }
    @Then("I will be redirected to my profile page")
    public void onProfilePage(){
        login.onProfilePage();
    }
    @And("I can see information about myself, such as work experience, education, and skills that LinkedIn has")
    public void seeInformationUser(){
        login.seeInformationUser();
    }
}
