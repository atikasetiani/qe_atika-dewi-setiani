package starter.login;
import net.thucydides.core.annotations.Step;
public class Search {
    @Step("I am on main LinkedIn page")
    public void onLinkedInPage(){
        System.out.println("I am on main LinkedIn page");
    }
    @Step("I type the keyword Software Engineer in the search field")
    public void typeTheKeyword(){
        System.out.println("I type the keyword Software Engineer in the search field");
    }
    @Step("I click enter in keyboard")
    public void clickEnter(){
        System.out.println("I click enter in keyboard");
    }
    @Step("I should see a list of user profiles related to the keyword Software Engineer")
    public void seeListOfUser(){
        System.out.println("I should see a list of user profiles related to the keyword Software Engineer");
    }
}
