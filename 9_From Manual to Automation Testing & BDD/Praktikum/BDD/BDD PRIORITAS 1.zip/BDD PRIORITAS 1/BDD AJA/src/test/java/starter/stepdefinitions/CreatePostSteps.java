package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.CreatePost;
import starter.login.Messages;

public class CreatePostSteps {
    @Steps
    CreatePost login;
    @Given("I am on the LinkedIn page")
    public void onLinkedInPage(){
        login.onLinkedInPage();
    }
    @When("I click the textbox Start a post button")
    public void clickTextBoxStartPost(){
        login.clickTextBoxStartPost();
    }
    @And("I typed text in the post column, an example Hai Everybody")
    public void TypedText(){login.TypedText();}
    @And("I load the image from my computer")
    public void loadTheImage(){
        login.loadTheImage();
    }
    @And("I click the Post button")
    public void clickPostButton(){
        login.clickPostButton();
    }
    @Then("I have to see my post on the LinkedIn feed page")
    public void seeMyPost(){
        login.seeMyPost();
    }
}
