package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.Search;

public class SearchSteps {
    @Steps
    Search login;
    @Given("I am on main LinkedIn page")
    public void onLinkedInPage(){
        login.onLinkedInPage();
    }
    @When("I type the keyword Software Engineer in the search field")
    public void typeTheKeyword(){
        login.typeTheKeyword();
    }
    @And("I click enter in keyboard")
    public void clickEnter(){
        login.clickEnter();
    }
    @Then("I should see a list of user profiles related to the keyword Software Engineer")
    public void seeListOfUser(){
        login.seeListOfUser();
    }
}
