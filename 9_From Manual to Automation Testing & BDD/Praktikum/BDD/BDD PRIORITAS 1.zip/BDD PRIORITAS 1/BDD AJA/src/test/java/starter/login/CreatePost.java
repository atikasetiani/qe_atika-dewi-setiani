package starter.login;

import net.thucydides.core.annotations.Step;

public class CreatePost {
    @Step("I am on the LinkedIn page")
    public void onLinkedInPage(){
        System.out.println("I am on the LinkedIn page");
    }
    @Step("I click the textbox Start a post button")
    public void clickTextBoxStartPost(){
        System.out.println("I click textbox Start a post button");
    }
    @Step("I typed text in the post column, an example Hai Everybody")
    public void TypedText(){
        System.out.println("I typed text in the post column, an example Hai Everybody");
    }
    @Step("I load the image from my computer")
    public void loadTheImage(){
        System.out.println("I load the image from my computer");
    }
    @Step("I click the Post button")
    public void clickPostButton(){
        System.out.println("I click the Post button");
    }
    @Step("I have to see my post on the LinkedIn feed page")
    public void seeMyPost(){
        System.out.println("I have to see my post on the LinkedIn feed page");
    }
}
