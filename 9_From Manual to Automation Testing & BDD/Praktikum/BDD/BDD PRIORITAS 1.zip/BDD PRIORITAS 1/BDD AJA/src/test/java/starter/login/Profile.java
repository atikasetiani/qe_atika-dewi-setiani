package starter.login;
import net.thucydides.core.annotations.Step;
public class Profile {
    @Step("I'm already logged in to my LinkedIn account")
    public void onTheLinkedInPage(){
        System.out.println("I'm already logged in to my LinkedIn account");
    }
    @Step("I clicked on my profile picture")
    public void clickProfilePicture(){
        System.out.println("I clicked on my profile picture");
    }
    @Step("I will be redirected to my profile page")
    public void onProfilePage(){
        System.out.println("I will be redirected to my profile page");
    }
    @Step("I can see information about myself, such as work experience, education, and skills that LinkedIn has")
    public void seeInformationUser(){
        System.out.println("I can see information about myself, such as work experience, education, and skills that LinkedIn has");
    }
}
