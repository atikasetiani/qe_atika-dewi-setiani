package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class AddNewProductCartPositif {
    protected String url = "https://fakestoreapi.com/";

    @Step("I set POST endpoints for cart")
    public String setPostApiEndpointforCart(){
        return url + "carts";
    }

    @Step("I send POST HTTP request for cart")
    public void sendPostHttpRequestintforCart(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("userId", 5);
        requestBody.put("date", "2020-02-03");

        JSONArray productsArray = new JSONArray();

        JSONObject product1 = new JSONObject();
        product1.put("productId", 5);
        product1.put("quantity", 1);
        productsArray.add(product1);

        JSONObject product2 = new JSONObject();
        product2.put("productId", 1);
        product2.put("quantity", 5);
        productsArray.add(product2);

        requestBody.put("products", productsArray);

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).post(setPostApiEndpointforCart());
    }

    @Step("I get valid HTTP response code 200 OK for cart")
    public void receiveHttpResponseCode200forCart(){
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("I receive valid data for new cart")
    public void validateDatanewCart() {
        restAssuredThat(response -> response.body("userId", equalTo(5)));
        restAssuredThat(response -> response.body("date", equalTo("2020-02-03")));
        restAssuredThat(response -> response.body("products[0].productId", equalTo(5)));
        restAssuredThat(response -> response.body("products[0].quantity", equalTo(1)));
        restAssuredThat(response -> response.body("products[1].productId", equalTo(1)));
        restAssuredThat(response -> response.body("products[1].quantity", equalTo(5)));
    }
}


