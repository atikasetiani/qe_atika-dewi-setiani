package starter.fakestoreapi.Product;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class UpdateProductUsingPutNegatif {

    protected String url = "https://fakestoreapi.com/";

    @Step("I set a PUT endpoints")
    public String setPutIDEndpoint(){
        return url + "products/7";
    }

    @Step("I send a PUT HTTP to the request part")
    public void sendPutIDHttpRequest(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("title", notNullValue());
        requestBody.put("price", notNullValue());
        requestBody.put("description", notNullValue());
        requestBody.put("image", notNullValue());
        requestBody.put("category", notNullValue());

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).put(setPutIDEndpoint());
    }

    @Step("I receive valid HTTP Put response code is 400 Bad Request")
    public void receiveResponseCode400BR(){
        restAssuredThat(response -> response.statusCode(400));
    }

    @Step("I didn't receive valid data for existing product")
    public void ValidateForExistingUser(){
        restAssuredThat(response -> response.body("'title'", notNullValue()));
        restAssuredThat(response -> response.body("'price'", notNullValue()));
        restAssuredThat(response -> response.body("'description'", notNullValue()));
        restAssuredThat(response -> response.body("'image'", notNullValue()));
        restAssuredThat(response -> response.body("'category'", notNullValue()));}
}
