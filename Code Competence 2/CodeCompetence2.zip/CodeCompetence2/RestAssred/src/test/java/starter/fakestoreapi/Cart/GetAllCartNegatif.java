package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class GetAllCartNegatif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set the GET endpoint part for cart")
    public String GetEndpointsforCart(){
        return url + "Cart";
    }
    @Step("I send a request to the HTTP GET part for cart")
    public void partGetHTTPRequestforCart(){
        SerenityRest.given()
                .when()
                .get(GetEndpointsforCart());
    }
    @Step("I receive a valid HTTP response code 404 Not Found for cart")
    public void HTTPresponse404forCart(){
        restAssuredThat(response ->response.statusCode(404));
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
    @Step("I didn't received valid data for all cart details")
    public void emptyDataCart() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
