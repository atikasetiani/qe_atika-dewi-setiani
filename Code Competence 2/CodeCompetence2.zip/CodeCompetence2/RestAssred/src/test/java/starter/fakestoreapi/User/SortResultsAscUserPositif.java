package starter.fakestoreapi.User;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class SortResultsAscUserPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set valid the sort endpoint for user")
    public String setSortAscEndpointsforUser(){
        return url + "users?sort=asc";

    }
    @Step("I sending a HTTP GET request for user")
    public void sendGETHTTPRequestforUser(){
        SerenityRest.given()
                .when()
                .get(setSortAscEndpointsforUser());

    }
    @Step("I received a 200 OK HTTP response code for user")
    public void sortAscHTTPResponse200forUser(){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I received valid data for all user details sequentially from id 1 to id 10")
    public void validSortDataAscendingUser() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
