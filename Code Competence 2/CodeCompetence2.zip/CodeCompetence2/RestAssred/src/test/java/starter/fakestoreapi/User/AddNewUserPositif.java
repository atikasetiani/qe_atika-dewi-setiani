package starter.fakestoreapi.User;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class AddNewUserPositif {
    protected String url = "https://fakestoreapi.com/";

    @Step("I set POST endpoints for user")
    public String setPostApiEndpointforUser(){
        return url + "users";
    }

    @Step("I send POST HTTP request for user")
    public void sendPostHttpRequestforUser(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("email", "John@gmail.com");
        requestBody.put("username", "johnd");
        requestBody.put("password", "m38rmF$");

        JSONObject name = new JSONObject();
        name.put("firstname", "John");
        name.put("lastname", "Doe");
        requestBody.put("name", name);

        JSONObject address = new JSONObject();
        address.put("city", "kilcoole");
        address.put("street", "7835 new road");
        address.put("number", 3);
        address.put("zipcode", "12926-3874");

        JSONObject geolocation = new JSONObject();
        geolocation.put("lat", "-37.3159");
        geolocation.put("long", "81.1496");
        address.put("geolocation", geolocation);

        requestBody.put("address", address);

        requestBody.put("phone", "1-570-236-7033");

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).post(setPostApiEndpointforUser());
    }

    @Step("I receive valid HTTP response code that is 200 OK for user")
    public void receiveHttpResponseCode200forUser(){
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("I receive valid data for new user")
    public void validateDatanewUser() {
        restAssuredThat(response -> response.body("email", equalTo("John@gmail.com")));
        restAssuredThat(response -> response.body("username", equalTo("johnd")));
        restAssuredThat(response -> response.body("password", equalTo("m38rmF$")));

        restAssuredThat(response -> response.body("name.firstname", equalTo("John")));
        restAssuredThat(response -> response.body("name.lastname", equalTo("Doe")));

        restAssuredThat(response -> response.body("address.city", equalTo("kilcoole")));
        restAssuredThat(response -> response.body("address.street", equalTo("7835 new road")));
        restAssuredThat(response -> response.body("address.number", equalTo(3)));
        restAssuredThat(response -> response.body("address.zipcode", equalTo("12926-3874")));

        restAssuredThat(response -> response.body("address.geolocation.lat", equalTo("-37.3159")));
        restAssuredThat(response -> response.body("address.geolocation.long", equalTo("81.1496")));

        restAssuredThat(response -> response.body("phone", equalTo("1-570-236-7033")));
    }
}

