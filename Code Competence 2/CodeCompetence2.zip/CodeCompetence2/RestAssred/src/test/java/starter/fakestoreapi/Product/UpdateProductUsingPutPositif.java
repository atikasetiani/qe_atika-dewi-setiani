package starter.fakestoreapi.Product;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class UpdateProductUsingPutPositif {
    protected String url = "https://fakestoreapi.com/";

    @Step("I set PUT endpoints")
    public String setPutEndpoint(){
        return url + "products/7";
    }

    @Step("I send PUT HTTP request")
    public void sendPutHttpRequest(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("title", "test product");
        requestBody.put("price", "13.5");
        requestBody.put("description", "lorem ipsum set");
        requestBody.put("image", "https://i.pravatar.cc");
        requestBody.put("category", "electronic");

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).put(setPutEndpoint());
    }

    @Step("I receive valid HTTP Put response code is 200 OK")
    public void receiveResponseCode200(){
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("I receive valid data for existing product")
    public void ValidateDataForExistingUser(){
        restAssuredThat(response -> response.body("'title'", equalTo("test product")));
        restAssuredThat(response -> response.body("'price'", equalTo("13.5")));
        restAssuredThat(response -> response.body("'description'", equalTo("lorem ipsum set")));
        restAssuredThat(response -> response.body("'image'", equalTo("https://i.pravatar.cc")));
        restAssuredThat(response -> response.body("'category'", equalTo("electronic")));
    }
}
