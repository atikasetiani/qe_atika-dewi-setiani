package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class LimitResultsCartPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set a GET endpoint with a limit of up to id 5 for cart")
    public String getLimitEndpointsforCart(){
        return url + "carts?limit=5";

    }
    @Step("I am sending a HTTP GET request for cart")
    public void getLimitHTTPRequestforCart(){
        SerenityRest.given()
                .when()
                .get(getLimitEndpointsforCart());

    }
    @Step("I get a valid HTTP response code which is 200 OK for cart")
    public void limitHTTPResponse200forCart(){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I received valid data for cart details from id 1 to id 5")
    public void valiDataLimitCart() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
