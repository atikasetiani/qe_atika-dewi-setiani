package starter.fakestoreapi.User;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class DeleteUserPositif {
    protected String url = "https://fakestoreapi.com/";
    @Step("I set DELETE endpoints for user")
    public String setDeleteEndpointforUser(){
        return url + "users/6";
    }
    @Step("I send DELETE HTTP request for user")
    public void sendDeleteHttpRequestforUser(){
        SerenityRest.given().delete(setDeleteEndpointforUser());
    }
    @Step("I receive valid DELETE HTTP response code 200 OK for user")
    public void validHttpresponseCode200forUser(){
        restAssuredThat(response -> response.statusCode(200));
    }
}
