package starter.fakestoreapi.User;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class GetAllUsersPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set a GET endpoints user")
    public String setGetEndpointsforUser(){
        return url + "users";

    }
    @Step("I send HTTP GET request for endpoints user")
    public void getHTTPrequestforUser(){
        SerenityRest.given()
                .when()
                .get(setGetEndpointsforUser());

    }
    @Step("I receive a valid HTTP response code 200 OK for user")
    public void HTTPresponse200forUser(){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I received valid data for all user details")
    public void valiDataUser() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
