package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class DeleteUserCartPositif {
    protected String url = "https://fakestoreapi.com/";
    @Step("I set DELETE endpoints for cart")
    public String setDeleteEndpointforUserCart(){
        return url + "carts/6";
    }
    @Step("I send DELETE HTTP request for cart")
    public void sendDeleteHttpRequestforUserCart(){
        SerenityRest.given().delete(setDeleteEndpointforUserCart());
    }
    @Step("I receive valid DELETE HTTP response code 200 OK for cart")
    public void validHttpresponseCode200forUserCart(){
        restAssuredThat(response -> response.statusCode(200));
    }
}
