package starter.StepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.fakestoreapi.Product.*;

public class ProductsSteps {
    @Steps
    GetAllProductsPositif getAllProductsPositif;
    @Steps
    GetAllProductsNegatif getAllProductsNegatif;
    @Steps
    GetSingleProductPositif getSingleProductPositif;
    @Steps
    LimitResultsProductPositif limitResultsProductPositif;
    @Steps
    LimitResultProductNegatif limitResultProductNegatif;
    @Steps
    SortResultsAscProductPositif sortResultsAscProductPositif;
    @Steps
    SortResultsDescProductPositif sortResultsDescProductPositif;
    @Steps
    GetAllCategoriesProductPositif getAllCategoriesProductPositif;
    @Steps
    GetAllCategoriesProductNegatif getAllCategoriesProductNegatif;
    @Steps
    GetProductSpesificCategoriesPositif getProductSpesificCategoriesPositif;
    @Steps
    AddNewProductPositif addNewProductPositif;
    @Steps
    AddNewProductNegatif addNewProductNegatif;
    @Steps
    UpdateProductUsingPutPositif updateProductUsingPutPositif;
    @Steps
    UpdateProductUsingPutNegatif updateProductUsingPutNegatif;
    @Steps
    DeleteProductPositif deleteProductPositif;

    @Given("I set a GET endpoints")
    public void setGetEndpoints(){getAllProductsPositif.setGetEndpoints();}
    @When("I send HTTP GET request")
    public void getHTTPrequest(){getAllProductsPositif.getHTTPrequest();}
    @Then("I receive a valid HTTP response code 200 OK")
    public void HTTPresponse200(){getAllProductsPositif.HTTPresponse200();}
    @And("I received valid data for all product details")
    public void valiData(){getAllProductsPositif.valiData();}

    @Given("I set the GET endpoint part")
    public void GetEndpoints(){getAllProductsNegatif.GetEndpoints();}
    @When("I send a request to the HTTP GET part")
    public void partGetHTTPRequest(){getAllProductsNegatif.partGetHTTPRequest();}
    @Then("I receive a valid HTTP response code 404 Not Found")
    public void HTTPresponse404(){getAllProductsNegatif.HTTPresponse404();}
    @And("I didn't received valid data for all product details")
    public void emptyData(){getAllProductsNegatif.emptyData();}

    @Given("I set a GET endpoints by ID 1")
    public void setGetIDEndpoints(){getSingleProductPositif.setGetIDEndpoints();}
    @When("I send HTTP GET to the request")
    public void getIDHTTPrequest(){getSingleProductPositif.getIDHTTPrequest();}
    @Then("I receive valid HTTP response code 200 OK")
    public void HTTPGetResponse200(){getSingleProductPositif.HTTPGetResponse200();}
    @And("I received valid data for single product details by ID 1")
    public void valiDataID(){getSingleProductPositif.valiDataID();}

    @Given("I set a GET endpoint with a limit of up to id 5")
    public void getLimitEndpoints(){limitResultsProductPositif.getLimitEndpoints();}
    @When("I am sending a HTTP GET request")
    public void getLimitHTTPRequest(){limitResultsProductPositif.getLimitHTTPRequest();}
    @Then("I get a valid HTTP response code which is 200 OK")
    public void limitHTTPResponse200(){limitResultsProductPositif.limitHTTPResponse200();}
    @And("I received valid data for product details from id 1 to id 5")
    public void valiDataLimit(){limitResultsProductPositif.valiDataLimit();}

    @Given("I set the wrong endpoint with limit up to id 5")
    public void getWrongLimitEndpoints(){limitResultProductNegatif.getWrongLimitEndpoints();}
    @When("I send a HTTP GET request")
    public void sendHTTPRequest(){limitResultProductNegatif.sendHTTPRequest();}
    @Then("I get HTTP response code which is 404 Not Found")
    public void limitHTTPResponse404(){limitResultProductNegatif.limitHTTPResponse404();}
    @And("I don't get valid data for product details from id 1 to id 5")
    public void emptyDataLimit(){limitResultProductNegatif.emptyDataLimit();}

    @Given("I set valid the sort endpoint")
    public void setSortAscEndpoints(){sortResultsAscProductPositif.setSortAscEndpoints();}
    @When("I sending a HTTP GET request")
    public void sendGETHTTPRequest(){sortResultsAscProductPositif.sendGETHTTPRequest();}
    @Then("I received a 200 OK HTTP response code")
    public void sortAscHTTPResponse200(){sortResultsAscProductPositif.sortAscHTTPResponse200();}
    @And("I received valid data for all product details sequentially from id 1 to id 20")
    public void validSortDataAscending(){sortResultsAscProductPositif.validSortDataAscending();}

    @Given("I set a sort descending endpoint")
    public void setSortDescEndpoints(){sortResultsDescProductPositif.setSortDescEndpoints();}
    @When("I send for a HTTP GET request")
    public void GETHTTPRequest(){sortResultsDescProductPositif.GETHTTPRequest();}
    @Then("I get a 200 OK HTTP response code")
    public void sortDescHTTPResponse200(){sortResultsDescProductPositif.sortDescHTTPResponse200();}
    @And("I get valid data for all product details sequentially from id 20 to id 1")
    public void validSortDataDescending(){sortResultsDescProductPositif.validSortDataDescending();}

    @Given("I set the product category endpoint")
    public void setCategoriesEndpoints(){getAllCategoriesProductPositif.setCategoriesEndpoints();}
    @When("I send a HTTP GET to the request")
    public void sendHTTPGETRequest(){getAllCategoriesProductPositif.sendHTTPGETRequest();}
    @Then("I receive a HTTP response code that is 200 OK")
    public void ResponseCode200(){getAllCategoriesProductPositif.ResponseCode200();}
    @And("I get data of all valid product category details")
    public void validCategories(){getAllCategoriesProductPositif.validCategories();}

    @Given("I set the wrong product category endpoint")
    public void setWrongCategoriesEndpoints(){getAllCategoriesProductNegatif.setWrongCategoriesEndpoints();}
    @When("I send a HTTP GET to request")
    public void sendaGETHTTPRequest(){getAllCategoriesProductNegatif.sendaGETHTTPRequest();}
    @Then("I received an HTTP response code which was 404 Not Found")
    public void ResponseCode404(){getAllCategoriesProductNegatif.ResponseCode404();}
    @And("I don't get all valid product category details data")
    public void emptyCategories(){getAllCategoriesProductNegatif.emptyCategories();}

    @Given("I set the product category specifically endpoint")
    public void setSpecificallyCategoriesEndpoints(){getProductSpesificCategoriesPositif.setSpecificallyCategoriesEndpoints();}
    @When("I sending HTTP GET request")
    public void sendHTTPRequestGET(){getProductSpesificCategoriesPositif.sendHTTPRequestGET();}
    @Then("I get HTTP response code 200 OK")
    public void ResponseCodeis200(){getProductSpesificCategoriesPositif.ResponseCodeis200();}
    @And("I get data of all specific valid product category details")
    public void validSpecificallyCategories(){getProductSpesificCategoriesPositif.validSpecificallyCategories();}

    @Given("I set POST endpoints")
    public void setPostApiEndpoint(){
        addNewProductPositif.setPostApiEndpoint();
    }
    @When("I send POST HTTP request")
    public void sendPostHTTPRequest(){
        addNewProductPositif.sendPostHttpRequest();
    }
    @Then("I get a valid HTTP response code that is 200 OK")
    public void receiveValidHttp201(){addNewProductPositif.receiveHttpResponseCode200();}
    @And("I receive valid data for new product")
    public void validateDataNewProduct(){
        addNewProductPositif.validateDatanewProduct();
    }

    @Given("I set the POST endpoints")
    public void setPostEndpoint(){
        addNewProductNegatif.setPostEndpoint();
    }
    @When("I send a request to the HTTP POST part")
    public void sendPostRequest(){
        addNewProductNegatif.sendPostRequest();
    }
    @Then("I receive valid HTTP response code 400 Bad Request")
    public void receiveHttpResponseCode400(){
        addNewProductNegatif.receiveHttpResponseCode400();
    }
    @And("I don't receive valid data for new product")
    public void validateDataProduct(){
        addNewProductNegatif.validateDataProduct();
    }

    @Given("I set PUT endpoints")
    public void setPutEndpoint(){
        updateProductUsingPutPositif.setPutEndpoint();
    }
    @When("I send PUT HTTP request")
    public void sendPutHttpRequest(){
        updateProductUsingPutPositif.sendPutHttpRequest();
    }
    @Then("I receive valid HTTP Put response code is 200 OK")
    public void receiveResponseCode200(){
        updateProductUsingPutPositif.receiveResponseCode200();
    }
    @And("I receive valid data for existing product")
    public void validateDataForExistingUser(){
        updateProductUsingPutPositif.ValidateDataForExistingUser();
    }

    @Given("I set a PUT endpoints")
    public void setPutIDEndpoint(){
        updateProductUsingPutNegatif.setPutIDEndpoint();
    }
    @When("I send a PUT HTTP to the request part")
    public void sendPutIDHttpRequest(){
        updateProductUsingPutNegatif.sendPutIDHttpRequest();
    }
    @Then("I receive valid HTTP Put response code is 400 Bad Request")
    public void receiveResponseCode400BR(){
        updateProductUsingPutNegatif.receiveResponseCode400BR();
    }
    @And("I didn't receive valid data for existing product")
    public void ValidateForExistingUser(){
        updateProductUsingPutNegatif.ValidateForExistingUser();
    }

    @Given("I set DELETE endpoints")
    public void setDeleteEndpoint(){
        deleteProductPositif.setDeleteEndpoint();
    }
    @When("I send DELETE HTTP request")
    public void sendDeleteHttpRequest(){
        deleteProductPositif.sendDeleteHttpRequest();
    }
    @Then("I receive valid DELETE HTTP response code 200 OK")
    public void validHttpresponseCode200(){deleteProductPositif.validHttpresponseCode200();}
}

