package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class SortResultsAscCartPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set valid the sort endpoint for cart")
    public String setSortAscEndpointsforCart(){
        return url + "carts?sort=asc";

    }
    @Step("I sending a HTTP GET request for cart")
    public void sendGETHTTPRequestforCart(){
        SerenityRest.given()
                .when()
                .get(setSortAscEndpointsforCart());

    }
    @Step("I received a 200 OK HTTP response code for cart")
    public void sortAscHTTPResponse200forCart(){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I received valid data for all cart details sequentially from id 1 to id 7")
    public void validSortDataAscendingCart() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
