package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class LimitResultCartNegatif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set the wrong endpoint with limit up to id 5 for cart")
    public String getWrongLimitEndpointsforCart(){
        return url + "product?limit=5";

    }
    @Step("I send a HTTP GET request for cart")
    public void sendHTTPRequestforCart(){
        SerenityRest.given()
                .when()
                .get(getWrongLimitEndpointsforCart());

    }
    @Step("I get HTTP response code which is 404 Not Found for cart")
    public void limitHTTPResponse404forCart(){
        restAssuredThat(response ->response.statusCode(404));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I don't get valid data for cart details from id 1 to id 5")
    public void emptyDataLimitCart() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
