package starter.fakestoreapi.User;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class LimitResultsUsersNegatif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set the wrong endpoint with limit up to id 5 for user")
    public String getWrongLimitEndpointsforUser(){
        return url + "user?limit=5";

    }
    @Step("I send a HTTP GET request for user")
    public void sendHTTPRequestforUser(){
        SerenityRest.given()
                .when()
                .get(getWrongLimitEndpointsforUser());

    }
    @Step("I get HTTP response code which is 404 Not Found for user")
    public void limitHTTPResponse404forUser(){
        restAssuredThat(response ->response.statusCode(404));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I don't get valid data for user details from id 1 to id 5")
    public void emptyDataLimitUser() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
