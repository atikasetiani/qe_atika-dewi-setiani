package starter.StepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.fakestoreapi.Login.LoginNegatif;

public class LoginSteps {
    @Steps
    LoginNegatif loginNegatif;

    @Given("I set POST endpoints for Login")
    public void setPostLoginEndpoints(){loginNegatif.setPostLoginEndpoints();}
    @When("I send POST HTTP request for login")
    public void sendPostRequest(){loginNegatif.sendPostRequest();}
    @Then("I get valid HTTP response code 400 Bad Request after login")
    public void getResponseCode400(){loginNegatif.getResponseCode400();}
    @And("I can't get token after login")
    public void validateLogin(){loginNegatif.validateLogin();}
}
