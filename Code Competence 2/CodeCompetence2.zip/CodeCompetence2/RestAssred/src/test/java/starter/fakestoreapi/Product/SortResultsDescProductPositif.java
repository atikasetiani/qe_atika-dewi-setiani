package starter.fakestoreapi.Product;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class SortResultsDescProductPositif {
    protected static String url = "https://fakestoreapi.com/";

    @Step("I set a sort descending endpoint")
    public String setSortDescEndpoints() {
        return url + "products?sort=desc";

    }

    @Step("I send for a HTTP GET request")
    public void GETHTTPRequest() {
        SerenityRest.given()
                .when()
                .get(setSortDescEndpoints());

    }

    @Step("I get a 200 OK HTTP response code")
    public void sortDescHTTPResponse200() {
        restAssuredThat(response -> response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I get valid data for all product details sequentially from id 20 to id 1")
    public void validSortDataDescending() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
