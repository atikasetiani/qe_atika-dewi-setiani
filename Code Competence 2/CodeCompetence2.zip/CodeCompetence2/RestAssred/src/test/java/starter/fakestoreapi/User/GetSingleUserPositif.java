package starter.fakestoreapi.User;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.equalTo;

public class GetSingleUserPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set a GET endpoints by ID 1 for user")
    public String setGetIDEndpointsforUser(){
        return url + "users/1";

    }
    @Step("I send HTTP GET to the request for user")
    public void getIDHTTPrequestforUser(){
        SerenityRest.given()
                .when()
                .get(setGetIDEndpointsforUser());

    }
    @Step("I receive valid HTTP response code 200 OK for user")
    public void HTTPGetResponse200forUser(){
        restAssuredThat(response ->response.statusCode(200));
    }

    @Step("I received valid data for single user details by ID 1")
    public void valiDataIDUser() {
        restAssuredThat(response -> response.body("id", equalTo(1)));
    }
}
