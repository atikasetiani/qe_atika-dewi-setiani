package starter.StepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.fakestoreapi.User.*;

public class UserSteps {
    @Steps
    GetAllUsersPositif getAllUsersPositif;
    @Steps
    GetAllUserNegatif getAllUsersNegatif;
    @Steps
    GetSingleUserPositif getSingleUserPositif;
    @Steps
    LimitResultsUsersPositif limitResultsUsersPositif;
    @Steps
    LimitResultsUsersNegatif limitResultsUsersNegatif;
    @Steps
    SortResultsAscUserPositif sortResultsAscUserPositif;
    @Steps
    SortResultsDescUserPositif sortResultsDescUserPositif;
    @Steps
    DeleteUserPositif deleteUserPositif;
    @Steps
    AddNewUserPositif addNewUserPositif;

    @Given("I set a GET endpoints user")
    public void setGetEndpointsforUser(){getAllUsersPositif.setGetEndpointsforUser();}
    @When("I send HTTP GET request for endpoints user")
    public void getHTTPrequestforUser(){getAllUsersPositif.getHTTPrequestforUser();}
    @Then("I receive a valid HTTP response code 200 OK for user")
    public void HTTPresponse200forUser(){getAllUsersPositif.HTTPresponse200forUser();}
    @And("I received valid data for all user details")
    public void valiDataUser(){getAllUsersPositif.valiDataUser();}

    @Given("I set the GET endpoint part for user")
    public void GetEndpointsforUser(){getAllUsersNegatif.GetEndpointsforUser();}
    @When("I send a request to the HTTP GET part for user")
    public void partGetHTTPRequestforUser(){getAllUsersNegatif.partGetHTTPRequestforUser();}
    @Then("I receive a valid HTTP response code 404 Not Found for user")
    public void HTTPresponse404forUser(){getAllUsersNegatif.HTTPresponse404forUser();}
    @And("I didn't received valid data for all user details")
    public void emptyDataUser(){getAllUsersNegatif.emptyDataUser();}

    @Given("I set a GET endpoints by ID 1 for user")
    public void setGetIDEndpointsforUser(){getSingleUserPositif.setGetIDEndpointsforUser();}
    @When("I send HTTP GET to the request for user")
    public void getIDHTTPrequestforUser(){getSingleUserPositif.getIDHTTPrequestforUser();}
    @Then("I receive valid HTTP response code 200 OK for user")
    public void HTTPGetResponse200forUser(){getSingleUserPositif.HTTPGetResponse200forUser();}
    @And("I received valid data for single user details by ID 1")
    public void valiDataIDUser(){getSingleUserPositif.valiDataIDUser();}

    @Given("I set a GET endpoint with a limit of up to id 5 for user")
    public void getLimitEndpointsforUser(){limitResultsUsersPositif.getLimitEndpointsforUser();}
    @When("I am sending a HTTP GET request for user")
    public void getLimitHTTPRequestforUser(){limitResultsUsersPositif.getLimitHTTPRequestforUser();}
    @Then("I get a valid HTTP response code which is 200 OK for user")
    public void limitHTTPResponse200forUser(){limitResultsUsersPositif.limitHTTPResponse200forUser();}
    @And("I received valid data for user details from id 1 to id 5")
    public void valiDataLimitUser(){limitResultsUsersPositif.valiDataLimitUser();}

    @Given("I set the wrong endpoint with limit up to id 5 for user")
    public void getWrongLimitEndpointsforUser(){limitResultsUsersNegatif.getWrongLimitEndpointsforUser();}
    @When("I send a HTTP GET request for user")
    public void sendHTTPRequestforUser(){limitResultsUsersNegatif.sendHTTPRequestforUser();}
    @Then("I get HTTP response code which is 404 Not Found for user")
    public void limitHTTPResponse404forUser(){limitResultsUsersNegatif.limitHTTPResponse404forUser();}
    @And("I don't get valid data for user details from id 1 to id 5")
    public void emptyDataLimitUser(){limitResultsUsersNegatif.emptyDataLimitUser();}

    @Given("I set valid the sort endpoint for user")
    public void setSortAscEndpointsforUser(){sortResultsAscUserPositif.setSortAscEndpointsforUser();}
    @When("I sending a HTTP GET request for user")
    public void sendGETHTTPRequestforUser(){sortResultsAscUserPositif.sendGETHTTPRequestforUser();}
    @Then("I received a 200 OK HTTP response code for user")
    public void sortAscHTTPResponse200forUser(){sortResultsAscUserPositif.sortAscHTTPResponse200forUser();}
    @And("I received valid data for all user details sequentially from id 1 to id 10")
    public void validSortDataAscendingUser(){sortResultsAscUserPositif.validSortDataAscendingUser();}

    @Given("I set a sort descending endpoint for user")
    public void setSortDescEndpointsforUser(){sortResultsDescUserPositif.setSortDescEndpointsforUser();}
    @When("I send for a HTTP GET request for user")
    public void GETHTTPRequestforUser(){sortResultsDescUserPositif.GETHTTPRequestforUser();}
    @Then("I get a 200 OK HTTP response code for user")
    public void sortDescHTTPResponse200forUser(){sortResultsDescUserPositif.sortDescHTTPResponse200forUser();}
    @And("I get valid data for all user details sequentially from id 10 to id 1")
    public void validSortDataDescendingUser(){sortResultsDescUserPositif.validSortDataDescendingUser();}

    @Given("I set DELETE endpoints for user")
    public void setDeleteEndpointforUser(){
        deleteUserPositif.setDeleteEndpointforUser();
    }
    @When("I send DELETE HTTP request for user")
    public void sendDeleteHttpRequestforUser(){
        deleteUserPositif.sendDeleteHttpRequestforUser();
    }
    @Then("I receive valid DELETE HTTP response code 200 OK for user")
    public void validHttpresponseCode200forUser(){deleteUserPositif.validHttpresponseCode200forUser();}

    @Given("I set POST endpoints for user")
    public void setPostApiEndpointforUser(){
        addNewUserPositif.setPostApiEndpointforUser();
    }
    @When("I send POST HTTP request for user")
    public void sendPostHTTPRequestforUser(){
        addNewUserPositif.sendPostHttpRequestforUser();
    }
    @Then("I receive valid HTTP response code that is 200 OK for user")
    public void receiveValidHttp200forUser(){addNewUserPositif.receiveHttpResponseCode200forUser();}
    @And("I receive valid data for new user")
    public void validateDatanewUser(){
        addNewUserPositif.validateDatanewUser();
    }
}
