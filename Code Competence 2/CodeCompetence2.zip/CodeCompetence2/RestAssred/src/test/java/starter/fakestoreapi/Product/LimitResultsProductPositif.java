package starter.fakestoreapi.Product;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class LimitResultsProductPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set a GET endpoint with a limit of up to id 5")
    public String getLimitEndpoints(){
        return url + "products?limit=5";

    }
    @Step("I am sending a HTTP GET request")
    public void getLimitHTTPRequest(){
        SerenityRest.given()
                .when()
                .get(getLimitEndpoints());

    }
    @Step("I get a valid HTTP response code which is 200 OK")
    public void limitHTTPResponse200(){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I received valid data for product details from id 1 to id 5")
    public void valiDataLimit() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}

