package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class UpdateCartUsingPutNegatif {

    protected String url = "https://fakestoreapi.com/";

    @Step("I set a PUT endpoints for cart")
    public String setPutIDEndpoints(){
        return url + "products/7";
    }

    @Step("I send a PUT HTTP to the request part for cart")
    public void sendPutIDHttpRequestCart(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("userId", notNullValue());
        requestBody.put("date", notNullValue());

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).put(setPutIDEndpoints());
    }

    @Step("I receive valid HTTP Put response code is 400 Bad Request for cart")
    public void receiveResponseCode400BRCart(){
        restAssuredThat(response -> response.statusCode(400));
    }

    @Step("I didn't receive valid data for existing product  for cart")
    public void ValidateForExistingUsingCart(){
        restAssuredThat(response -> response.body("userId", notNullValue()));
        restAssuredThat(response -> response.body("date", notNullValue()));
    }
}
