package starter.fakestoreapi.Product;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.equalTo;

public class GetSingleProductPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set a GET endpoints by ID 1")
    public String setGetIDEndpoints(){
        return url + "products/1";

    }
    @Step("I send HTTP GET to the request")
    public void getIDHTTPrequest(){
        SerenityRest.given()
                .when()
                .get(setGetIDEndpoints());

    }
    @Step("I receive valid HTTP response code 200 OK")
    public void HTTPGetResponse200(){
        restAssuredThat(response ->response.statusCode(200));
    }

    @Step("I received valid data for single product details by ID 1")
    public void valiDataID() {
        restAssuredThat(response -> response.body("id", equalTo(1)));
    }
}
