package starter.fakestoreapi.Login;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class LoginNegatif {
    protected String url = "https://fakestoreapi.com/";

    @Step("I set POST endpoints for Login")
    public String setPostLoginEndpoints(){
        return url + "auth/login";
    }

    @Step("I send POST HTTP request for login")
    public void sendPostRequest(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("username", notNullValue());
        requestBody.put("password", notNullValue());

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).post(setPostLoginEndpoints());
    }

    @Step("I get valid HTTP response code 400 Bad Request after login")
    public void getResponseCode400(){
        restAssuredThat(response -> response.statusCode(400));
    }

    @Step("I can't get token after login")
    public void validateLogin(){
        restAssuredThat(response -> response.body("'username'", notNullValue()));
        restAssuredThat(response -> response.body("'password'", notNullValue()));
    }
}

