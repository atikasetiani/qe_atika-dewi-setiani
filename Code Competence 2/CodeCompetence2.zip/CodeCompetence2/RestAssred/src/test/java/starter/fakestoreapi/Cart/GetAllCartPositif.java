package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class GetAllCartPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set a GET endpoints for cart")
    public String setGetEndpointsforCart(){
        return url + "carts";

    }
    @Step("I send HTTP GET request for cart")
    public void getHTTPrequestforCart(){
        SerenityRest.given()
                .when()
                .get(setGetEndpointsforCart());

    }
    @Step("I receive a valid HTTP response code 200 OK for cart")
    public void HTTPresponse200forCart(){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I received valid data for all cart details")
    public void valiDataCart() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
