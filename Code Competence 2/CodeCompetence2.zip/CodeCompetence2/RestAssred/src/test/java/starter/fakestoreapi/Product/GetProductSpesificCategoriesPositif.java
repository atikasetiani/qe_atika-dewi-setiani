package starter.fakestoreapi.Product;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class GetProductSpesificCategoriesPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set the product category specifically endpoint")
    public String setSpecificallyCategoriesEndpoints(){
        return url + "products/category/jewelery";
    }
    @Step("I sending HTTP GET request")
    public void sendHTTPRequestGET(){
        SerenityRest.given()
                .when()
                .get(setSpecificallyCategoriesEndpoints());
    }
    @Step("I get HTTP response code 200 OK")
    public void ResponseCodeis200(){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
    @Step("I get data of all specific valid product category details")
    public void validSpecificallyCategories() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
