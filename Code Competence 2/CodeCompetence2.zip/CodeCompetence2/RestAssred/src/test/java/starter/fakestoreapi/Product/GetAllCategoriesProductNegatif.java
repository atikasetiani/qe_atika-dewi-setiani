package starter.fakestoreapi.Product;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class GetAllCategoriesProductNegatif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set the wrong product category endpoint")
    public String setWrongCategoriesEndpoints(){
        return url + "product/categories";
    }
    @Step("I send a HTTP GET to request")
    public void sendaGETHTTPRequest(){
        SerenityRest.given()
                .when()
                .get(setWrongCategoriesEndpoints());
    }
    @Step("I received an HTTP response code which was 404 Not Found")
    public void ResponseCode404(){
        restAssuredThat(response ->response.statusCode(404));
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
    @Step("I don't get all valid product category details data")
    public void emptyCategories() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
