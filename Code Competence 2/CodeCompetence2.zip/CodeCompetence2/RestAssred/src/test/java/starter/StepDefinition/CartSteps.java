package starter.StepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.fakestoreapi.Cart.*;

public class CartSteps {
        @Steps
        GetAllCartPositif getAllCartPositif;
        @Steps
        GetAllCartNegatif getAllCartNegatif;
        @Steps
        GetSingleCartPositif getSingleCartPositif;
        @Steps
        LimitResultsCartPositif limitResultsCartPositif;
        @Steps
        LimitResultCartNegatif limitResultCartNegatif;
        @Steps
        SortResultsAscCartPositif sortResultsAscCartPositif;
        @Steps
        SortResultsDescCartPositif sortResultsDescCartPositif;
        @Steps
        GetCartsDateRangePositif getCartsDateRangePositif;
        @Steps
        GetCartsDateRangeNegatif getCartsDateRangeNegatif;
        @Steps
        GetUserCartPositif getUserCartPositif;
        @Steps
        AddNewProductCartPositif addNewProductCartPositif;
        @Steps
        AddNewProductCartNegatif addNewProductCartNegatif;
        @Steps
        DeleteUserCartPositif deleteUserCartPositif;
        @Steps
        UpdateCartUsingPutPositif updateCartUsingPutPositif;
        @Steps
        UpdateCartUsingPutNegatif updateCartUsingPutNegatif;


        @Given("I set a GET endpoints for cart")
        public void setGetEndpointsforCart(){getAllCartPositif.setGetEndpointsforCart();}
        @When("I send HTTP GET request for cart")
        public void getHTTPrequestforCart(){getAllCartPositif.getHTTPrequestforCart();}
        @Then("I receive a valid HTTP response code 200 OK for cart")
        public void HTTPresponse200forCart(){getAllCartPositif.HTTPresponse200forCart();}
        @And("I received valid data for all cart details")
        public void valiDataCart(){getAllCartPositif.valiDataCart();}

        @Given("I set the GET endpoint part for cart")
        public void GetEndpointsforCart(){getAllCartNegatif.GetEndpointsforCart();}
        @When("I send a request to the HTTP GET part for cart")
        public void partGetHTTPRequestforCart(){getAllCartNegatif.partGetHTTPRequestforCart();}
        @Then("I receive a valid HTTP response code 404 Not Found for cart")
        public void HTTPresponse404forCart(){getAllCartNegatif.HTTPresponse404forCart();}
        @And("I didn't received valid data for all cart details")
        public void emptyDataCart(){getAllCartNegatif.emptyDataCart();}

        @Given("I set a GET endpoints by ID 5 for cart")
        public void setGetIDEndpointsforCart(){getSingleCartPositif.setGetIDEndpointsforCart();}
        @When("I send HTTP GET to the request for cart")
        public void getIDHTTPrequestforCart(){getSingleCartPositif.getIDHTTPrequestforCart();}
        @Then("I receive valid HTTP response code 200 OK for cart")
        public void HTTPGetResponse200forCart(){getSingleCartPositif.HTTPGetResponse200forCart();}
        @And("I received valid data for single cart details by ID 5")
        public void valiDataIDCart(){getSingleCartPositif.valiDataIDCart();}

        @Given("I set a GET endpoint with a limit of up to id 5 for cart")
        public void getLimitEndpointsforCart(){limitResultsCartPositif.getLimitEndpointsforCart();}
        @When("I am sending a HTTP GET request for cart")
        public void getLimitHTTPRequestforCart(){limitResultsCartPositif.getLimitHTTPRequestforCart();}
        @Then("I get a valid HTTP response code which is 200 OK for cart")
        public void limitHTTPResponse200forCart(){limitResultsCartPositif.limitHTTPResponse200forCart();}
        @And("I received valid data for cart details from id 1 to id 5")
        public void valiDataLimitCart(){limitResultsCartPositif.valiDataLimitCart();}

        @Given("I set the wrong endpoint with limit up to id 5 for cart")
        public void getWrongLimitEndpointsforCart(){limitResultCartNegatif.getWrongLimitEndpointsforCart();}
        @When("I send a HTTP GET request for cart")
        public void sendHTTPRequestforCart(){limitResultCartNegatif.sendHTTPRequestforCart();}
        @Then("I get HTTP response code which is 404 Not Found for cart")
        public void limitHTTPResponse404forCart(){limitResultCartNegatif.limitHTTPResponse404forCart();}
        @And("I don't get valid data for cart details from id 1 to id 5")
        public void emptyDataLimitCart(){limitResultCartNegatif.emptyDataLimitCart();}

        @Given("I set valid the sort endpoint for cart")
        public void setSortAscEndpointsforCart(){sortResultsAscCartPositif.setSortAscEndpointsforCart();}
        @When("I sending a HTTP GET request for cart")
        public void sendGETHTTPRequestforCart(){sortResultsAscCartPositif.sendGETHTTPRequestforCart();}
        @Then("I received a 200 OK HTTP response code for cart")
        public void sortAscHTTPResponse200forCart(){sortResultsAscCartPositif.sortAscHTTPResponse200forCart();}
        @And("I received valid data for all cart details sequentially from id 1 to id 7")
        public void validSortDataAscendingCart(){sortResultsAscCartPositif.validSortDataAscendingCart();}

        @Given("I set a sort descending endpoint for cart")
        public void setSortDescEndpointsforCart(){sortResultsDescCartPositif.setSortDescEndpointsforCart();}
        @When("I send for a HTTP GET request for cart")
        public void GETHTTPRequestforCartforCart(){sortResultsDescCartPositif.GETHTTPRequestforCart();}
        @Then("I get a 200 OK HTTP response code for cart")
        public void sortDescHTTPResponse200forCart(){sortResultsDescCartPositif.sortDescHTTPResponse200forCart();}
        @And("I get valid data for all cart details sequentially from id 7 to id 1")
        public void validSortDataDescendingCart(){sortResultsDescCartPositif.validSortDataDescendingCart();}

        @Given("I set the cart endpoint")
        public void setCartEndpoint(){getCartsDateRangePositif.setCartEndpoint();}
        @When("I send a HTTP GET to the request for cart")
        public void RequestforDateCart(){getCartsDateRangePositif.RequestforDateCart();}
        @Then("I receive a HTTP response code that is 200 OK for cart")
        public void Response200forDateCart(){getCartsDateRangePositif.Response200forDateCart();}
        @And("I get data of all valid cart in a date range details")
        public void validcartDateRange(){getCartsDateRangePositif.validcartDateRange();}

        @Given("I set the wrong cart endpoint")
        public void setWrongCartEndpoint(){getCartsDateRangeNegatif.setWrongCartEndpoint();}
        @When("I send a HTTP GET to request for cart")
        public void RequestDateCart(){getCartsDateRangeNegatif.RequestDateCart();}
        @Then("I received an HTTP response code which was 404 Not Found for cart")
        public void Response404forDateCart(){getCartsDateRangeNegatif.Response404forDateCart();}
        @And("I don't get all valid cart in a date range")
        public void emptycartDateRange(){getCartsDateRangeNegatif.emptycartDateRange();}

        @Given("I set the user cart endpoint")
        public void setUserCartEndpoint(){getUserCartPositif.setUserCartEndpoint();}
        @When("I sending HTTP GET request for cart")
        public void RequestHTTPGETUserCart(){getUserCartPositif.RequestHTTPGETUserCart();}
        @Then("I get HTTP response code 200 OK for cart")
        public void Response200forUserCart(){getUserCartPositif.Response200forUserCart();}
        @And("I get data of all specific valid user cart details")
        public void validUserCart(){getUserCartPositif.validUserCart();}

        @Given("I set POST endpoints for cart")
        public void setPostApiEndpointforCart(){
                addNewProductCartPositif.setPostApiEndpointforCart();
        }
        @When("I send POST HTTP request for cart")
        public void sendPostHttpRequestintforCart(){
                addNewProductCartPositif.sendPostHttpRequestintforCart();
        }
        @Then("I get valid HTTP response code 200 OK for cart")
        public void receiveHttpResponseCode200forCart(){addNewProductCartPositif.receiveHttpResponseCode200forCart();}
        @And("I receive valid data for new cart")
        public void validateDatanewCart(){
                addNewProductCartPositif.validateDatanewCart();
        }

        @Given("I set the POST endpoints for cart")
        public void setPostApiEndpointsforCart(){
                addNewProductCartNegatif.setPostApiEndpointsforCart();
        }
        @When("I send a request to the HTTP POST part for cart")
        public void sendPostRequestintforCart(){
                addNewProductCartNegatif.sendPostRequestintforCart();
        }
        @Then("I receive valid HTTP response code 400 Bad Request for cart")
        public void receiveResponseCode400forCart(){addNewProductCartNegatif.receiveResponseCode400forCart();}
        @And("I don't receive valid data for new cart")
        public void validateDatanewsCart(){
                addNewProductCartNegatif.validateDatanewsCart();
        }

        @Given("I set PUT endpoints for cart")
        public void setPutEndpointCart(){
                updateCartUsingPutPositif.setPutEndpointCart();
        }
        @When("I send PUT HTTP request for cart")
        public void sendPutHttpRequestCart(){
                updateCartUsingPutPositif.sendPutHttpRequestCart();
        }
        @Then("I receive valid HTTP Put response code is 200 OK for cart")
        public void receiveResponseCode200OKPut(){ updateCartUsingPutPositif.receiveResponseCode200OKPut();}
        @And("I receive valid data for existing cart")
        public void ValidateDataForExistingCart(){
                updateCartUsingPutPositif.ValidateDataForExistingCart();
        }

        @Given("I set a PUT endpoints for cart")
        public void setPutIDEndpoints(){ updateCartUsingPutNegatif.setPutIDEndpoints();}
        @When("I send a PUT HTTP to the request part for cart")
        public void sendPutIDHttpRequestCart(){
                updateCartUsingPutNegatif.sendPutIDHttpRequestCart();
        }
        @Then("I receive valid HTTP Put response code is 400 Bad Request for cart")
        public void receiveResponseCode400BRCart(){ updateCartUsingPutNegatif.receiveResponseCode400BRCart();}
        @And("I didn't receive valid data for existing product  for cart")
        public void ValidateForExistingUsingCart(){
                updateCartUsingPutNegatif.ValidateForExistingUsingCart();
        }

        @Given("I set DELETE endpoints for cart")
        public void setDeleteEndpointforUserCart(){
            deleteUserCartPositif.setDeleteEndpointforUserCart();
        }
        @When("I send DELETE HTTP request for cart")
        public void sendDeleteHttpRequestforUserCart(){
            deleteUserCartPositif.sendDeleteHttpRequestforUserCart();
        }
        @Then("I receive valid DELETE HTTP response code 200 OK for cart")
        public void validHttpresponseCode200forUserCart(){deleteUserCartPositif.validHttpresponseCode200forUserCart();}
}
