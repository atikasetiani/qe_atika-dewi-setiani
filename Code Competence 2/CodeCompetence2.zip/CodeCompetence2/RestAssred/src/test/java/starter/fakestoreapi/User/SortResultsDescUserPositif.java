package starter.fakestoreapi.User;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class SortResultsDescUserPositif {
    protected static String url = "https://fakestoreapi.com/";

    @Step("I set a sort descending endpoint for user")
    public String setSortDescEndpointsforUser() {
        return url + "users?sort=desc";

    }

    @Step("I send for a HTTP GET request for user")
    public void GETHTTPRequestforUser() {
        SerenityRest.given()
                .when()
                .get(setSortDescEndpointsforUser());

    }

    @Step("I get a 200 OK HTTP response code for user")
    public void sortDescHTTPResponse200forUser() {
        restAssuredThat(response -> response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I get valid data for all user details sequentially from id 10 to id 1")
    public void validSortDataDescendingUser() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
