package starter.fakestoreapi.User;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class LimitResultsUsersPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set a GET endpoint with a limit of up to id 5 for user")
    public String getLimitEndpointsforUser(){
        return url + "users?limit=5";

    }
    @Step("I am sending a HTTP GET request for user")
    public void getLimitHTTPRequestforUser(){
        SerenityRest.given()
                .when()
                .get(getLimitEndpointsforUser());

    }
    @Step("I get a valid HTTP response code which is 200 OK for user")
    public void limitHTTPResponse200forUser(){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I received valid data for user details from id 1 to id 5")
    public void valiDataLimitUser() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
