package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class SortResultsDescCartPositif {
    protected static String url = "https://fakestoreapi.com/";

    @Step("I set a sort descending endpoint for cart")
    public String setSortDescEndpointsforCart() {
        return url + "carts?sort=desc";

    }

    @Step("I send for a HTTP GET request for cart")
    public void GETHTTPRequestforCart() {
        SerenityRest.given()
                .when()
                .get(setSortDescEndpointsforCart());

    }

    @Step("I get a 200 OK HTTP response code for cart")
    public void sortDescHTTPResponse200forCart() {
        restAssuredThat(response -> response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I get valid data for all cart details sequentially from id 7 to id 1")
    public void validSortDataDescendingCart() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
