package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class GetCartsDateRangePositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set the cart endpoint")
    public String setCartEndpoint(){
        return url + "carts?startdate=2019-12-10&enddate=2020-10-10";

    }
    @Step("I send a HTTP GET to the request for cart")
    public void RequestforDateCart(){
        SerenityRest.given()
                .when()
                .get(setCartEndpoint());

    }
    @Step("I receive a HTTP response code that is 200 OK for cart")
    public void Response200forDateCart(){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I get data of all valid cart in a date range details")
    public void validcartDateRange() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
