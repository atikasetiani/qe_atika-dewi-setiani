package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.equalTo;

public class GetSingleCartPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set a GET endpoints by ID 5 for cart")
    public String setGetIDEndpointsforCart(){
        return url + "carts/5";

    }
    @Step("I send HTTP GET to the request for cart")
    public void getIDHTTPrequestforCart(){
        SerenityRest.given()
                .when()
                .get(setGetIDEndpointsforCart());

    }
    @Step("I receive valid HTTP response code 200 OK for cart")
    public void HTTPGetResponse200forCart(){
        restAssuredThat(response ->response.statusCode(200));
    }

    @Step("I received valid data for single cart details by ID 5")
    public void valiDataIDCart() {
        restAssuredThat(response -> response.body("id", equalTo(5)));
    }
}
