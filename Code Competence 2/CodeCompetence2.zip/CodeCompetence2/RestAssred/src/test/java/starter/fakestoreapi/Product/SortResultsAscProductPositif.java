package starter.fakestoreapi.Product;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class SortResultsAscProductPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set valid the sort endpoint")
    public String setSortAscEndpoints(){
        return url + "products?sort=asc";

    }
    @Step("I sending a HTTP GET request")
    public void sendGETHTTPRequest(){
        SerenityRest.given()
                .when()
                .get(setSortAscEndpoints());

    }
    @Step("I received a 200 OK HTTP response code")
    public void sortAscHTTPResponse200(){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I received valid data for all product details sequentially from id 1 to id 20")
    public void validSortDataAscending() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
