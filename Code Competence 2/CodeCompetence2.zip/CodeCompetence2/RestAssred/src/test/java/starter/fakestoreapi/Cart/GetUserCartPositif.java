package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class GetUserCartPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set the user cart endpoint")
    public String setUserCartEndpoint(){
        return url + "carts/user/2";

    }
    @Step("I sending HTTP GET request for cart")
    public void RequestHTTPGETUserCart(){
        SerenityRest.given()
                .when()
                .get(setUserCartEndpoint());

    }
    @Step("I get HTTP response code 200 OK for cart")
    public void Response200forUserCart(){
        restAssuredThat(response ->response.statusCode(400));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I get data of all specific valid user cart details")
    public void validUserCart() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
