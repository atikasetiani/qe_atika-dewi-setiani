package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class AddNewProductCartNegatif {
    protected String url = "https://fakestoreapi.com/";

    @Step("I set the POST endpoints for cart")
    public String setPostApiEndpointsforCart(){
        return url + "carts";
    }

    @Step("I send a request to the HTTP POST part for cart")
    public void sendPostRequestintforCart(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("userId", notNullValue());
        requestBody.put("date", notNullValue());

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).post(setPostApiEndpointsforCart());
    }

    @Step("I receive valid HTTP response code 400 Bad Request for cart")
    public void receiveResponseCode400forCart(){
        restAssuredThat(response -> response.statusCode(400));
    }

    @Step("I don't receive valid data for new cart")
    public void validateDatanewsCart() {
        restAssuredThat(response -> response.body("userId", notNullValue()));
        restAssuredThat(response -> response.body("date", notNullValue()));

    }
}

