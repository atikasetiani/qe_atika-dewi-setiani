package starter.fakestoreapi.Product;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class GetAllCategoriesProductPositif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set the product category endpoint")
    public String setCategoriesEndpoints(){
        return url + "products/categories";
    }
    @Step("I send a HTTP GET to the request")
    public void sendHTTPGETRequest(){
        SerenityRest.given()
                .when()
                .get(setCategoriesEndpoints());
    }
    @Step("I receive a HTTP response code that is 200 OK")
    public void ResponseCode200(){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
    @Step("I get data of all valid product category details")
    public void validCategories() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
