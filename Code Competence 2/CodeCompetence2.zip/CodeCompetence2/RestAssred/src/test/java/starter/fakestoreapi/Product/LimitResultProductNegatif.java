package starter.fakestoreapi.Product;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class LimitResultProductNegatif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set the wrong endpoint with limit up to id 5")
    public String getWrongLimitEndpoints(){
        return url + "product?limit=5";

    }
    @Step("I send a HTTP GET request")
    public void sendHTTPRequest(){
        SerenityRest.given()
                .when()
                .get(getWrongLimitEndpoints());

    }
    @Step("I get HTTP response code which is 404 Not Found")
    public void limitHTTPResponse404(){
        restAssuredThat(response ->response.statusCode(404));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I don't get valid data for product details from id 1 to id 5")
    public void emptyDataLimit() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
