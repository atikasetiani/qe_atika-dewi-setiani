package starter.fakestoreapi.Cart;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class GetCartsDateRangeNegatif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set the wrong cart endpoint")
    public String setWrongCartEndpoint(){
        return url + "cart?startdate=2019-12-10&enddate=2020-10-10";

    }
    @Step("I send a HTTP GET to request for cart")
    public void RequestDateCart(){
        SerenityRest.given()
                .when()
                .get(setWrongCartEndpoint());

    }
    @Step("I received an HTTP response code which was 404 Not Found for cart")
    public void Response404forDateCart(){
        restAssuredThat(response ->response.statusCode(404));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I don't get all valid cart in a date range")
    public void emptycartDateRange() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
