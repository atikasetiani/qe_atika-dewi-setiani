package starter.fakestoreapi.User;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;

public class GetAllUserNegatif {
    protected static String url = "https://fakestoreapi.com/";
    @Step("I set the GET endpoint part for user")
    public String GetEndpointsforUser(){
        return url + "user";

    }
    @Step("I send a request to the HTTP GET part for user")
    public void partGetHTTPRequestforUser(){
        SerenityRest.given()
                .when()
                .get(GetEndpointsforUser());

    }
    @Step("I receive a valid HTTP response code 404 Not Found for user")
    public void HTTPresponse404forUser(){
        restAssuredThat(response ->response.statusCode(404));
        restAssuredThat(response -> response.body("$", notNullValue()));

    }

    @Step("I didn't received valid data for all user details")
    public void emptyDataUser() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
