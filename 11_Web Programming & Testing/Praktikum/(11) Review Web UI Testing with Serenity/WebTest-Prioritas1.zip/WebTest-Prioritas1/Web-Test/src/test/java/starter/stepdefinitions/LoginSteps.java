package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.Home;
import starter.login.Login;
import starter.login.ProductsPage;

public class LoginSteps {
    @Steps
    Login login;
    @Steps
    Home home;
    @Steps
    ProductsPage productsPage;

    @Given("I am on the login page")
    public void onTheLoginPage(){
        login.openUrl("https://www.saucedemo.com/");
        login.validateOnTheLoginPage();
    }

    @When("I enter valid username")
    public void enterValidUsername(){
        login.inputUsername("standard_user");
    }

    @When("I enter invalid username")
    public void enterinValidUsername(){
        login.inputUsername("standard_use");
    }

    @And("I enter valid password")
    public void enterValidPassword(){
        login.inputPassword("secret_sauce");
    }

    @And("I enter invalid password")
    public void enterinValidPassword(){
        login.inputPassword("secre_sauce");
    }

    @And("I click login button")
    public void clickLoginButton(){
        login.clickLoginButton();
    }

    @And("I click burger button")
    public void clickBurgerButton(){
        login.clickBurgerButton();
    }

    @And("I click logout menu")
    public void clickLogOutMenu(){
        login.clickLogOutMenu();
    }

    @And("I click add card button")
    public void clickAddCardButton(){
        productsPage.clickAddCardButton();
    }

    @And("I click added to cart")
    public void clickCartIcon(){productsPage.clickCartIcon();}

    @Then("I am on the home page")
    public void onTheHomePage(){
        home.validateOnTheHomePage();
    }

    @Then("I am success for logout")
    public void validateLogOut(){login.validateOnTheLoginPage();}

    @Then("I can't be on the home page")
    public void cantTheHomePage(){login.validateOnTheLoginPage();}

    @Then("I am should see the product added to cart")
    public void validateOnTheAddCard(){productsPage.validateOnTheAddCard();}
}
