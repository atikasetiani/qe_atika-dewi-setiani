package starter.login;

import net.serenitybdd.screenplay.actions.OpenUrl;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

public class ProductsPage extends PageObject {
    private By addCardButton(){
        return By.id("add-to-cart-sauce-labs-bolt-t-shirt");
    }
    private By addCartIcon(){
        return By.id("shopping_cart_container");
    }

    @Step
    public static OpenUrl url(String targetUrl){
        return new OpenUrl(targetUrl);
    }
    @Step
    public void validateOnTheAddCard(){
        $(addCartIcon()).isDisplayed();
    }
    @Step
    public void clickAddCardButton(){
        $(addCardButton()).click();
    }
    @Step
    public void clickCartIcon(){
        $(addCartIcon()).click();
    }
}
