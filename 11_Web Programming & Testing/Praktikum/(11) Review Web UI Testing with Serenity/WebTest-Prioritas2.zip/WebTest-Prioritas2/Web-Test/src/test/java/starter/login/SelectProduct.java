package starter.login;

import net.serenitybdd.screenplay.actions.OpenUrl;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

public class SelectProduct extends PageObject {
    private By phoneNumberField(){
        return By.id("phone_number");
    }
    private By nominalItem(){
        return By.id("Telkomsel Rp5.000");
    }
    private By operatorItem(){
        return By.id("product_type_0");
    }
    private By ProductIcon(){
        return By.id("Pulsa");
    }

    @Step
    public static OpenUrl url(String targetUrl){
        return new OpenUrl(targetUrl);
    }
    @Step
    public void selectPulsaIcon(){
        $(ProductIcon()).isDisplayed();
    }
    @Step
    public void clickOperatorItem(){
        $(operatorItem()).click();
    }
    @Step
    public void inputphoneNumber(String PhoneNumber){
        $(phoneNumberField()).type(PhoneNumber);
    }
    @Step
    public void selectNominal(){
        $(nominalItem()).click();
    }
    @Step
    public void validatePaymentdetails(){
        $(ProductIcon()).click();
    }
}
