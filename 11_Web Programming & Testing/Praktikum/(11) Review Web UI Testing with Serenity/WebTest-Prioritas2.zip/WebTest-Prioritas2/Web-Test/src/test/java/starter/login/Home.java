package starter.login;

import net.serenitybdd.screenplay.actions.OpenUrl;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

public class Home extends PageObject {
    private By title(){
        return By.className("homepage");
    }

    public void validateOnTheHomePage(){
        $(title()).isDisplayed();
    }
}
