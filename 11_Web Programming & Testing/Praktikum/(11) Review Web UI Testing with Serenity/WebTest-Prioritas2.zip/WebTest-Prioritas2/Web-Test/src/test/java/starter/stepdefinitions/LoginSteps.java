package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.Home;
import starter.login.Login;
import starter.login.SelectProduct;

public class LoginSteps {
    @Steps
    Login login;

    @Steps
    Home home;

    @Steps
    SelectProduct selectProduct;


    @Given("I am on the home page")
    public void onTheHomePageBeforeLogin(){
        login.openUrl("https://www.sepulsa.com/");
        home.validateOnTheHomePage();}

    @And("I click signin button")
    public void clickSigninButton(){
        login.clickSigninButton();
    }

    @And("I click the Pulsa icon")
    public void selectPulsaIcon(){selectProduct.selectPulsaIcon();}

    @And("I select Telkomsel operator")
    public void clickOperatorItem(){selectProduct.clickOperatorItem();}

    @Then("I am on the login page")
    public void validateOnTheLoginPage(){login.validateOnTheLoginPage();}

    @When("I enter valid email")
    public void enterValidEmail(){login.inputEmail("setianiatikadewi@gmail.com");}

    @When("I enter invalid email")
    public void enterinValidEmail(){login.inputEmail("setianiatika@gmail.com");}

    @And("I enter valid password")
    public void enterValidPassword(){login.inputPassword("Atika2112");}

    @And("I Enter the valid operator number")
    public void enterValidNumberPhone(){selectProduct.inputphoneNumber("082136577680");}

    @And("I enter invalid password")
    public void enterinValidPassword(){login.inputPassword("Atika21");}

    @And("I click submit button")
    public void clickSubmitButton(){
        login.clickSubmitButton();
    }

    @And("I select and click the desired credit amound")
    public void clickNominalProduct(){selectProduct.selectNominal();}

    @Then("I am success to login")
    public void onTheLoginPage(){login.validateOnTheLoginPage();}

    @Then("I am failed to login")
    public void onLoginPage(){login.validateOnTheLoginPage();}

    @Then("I am success on the home page")
    public void onTheHomePage(){home.validateOnTheHomePage();}

    @Then("I see payment detail")
    public void validatePaymentdetails(){home.validateOnTheHomePage();}
}
