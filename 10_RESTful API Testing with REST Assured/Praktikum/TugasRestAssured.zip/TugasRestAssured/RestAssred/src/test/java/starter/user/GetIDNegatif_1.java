package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class GetIDNegatif_1 {
    protected static String url = "https://jsonplaceholder.typicode.com/";
    @Step("I set a GET endpoints by ID 0")
    public String setGetID0Endpoints(){
        return url + "posts/0";

    }
    @Step("I send HTTP GET the request")
    public void getID0HTTPrequest(){
        SerenityRest.given()
                .when()
                .get(setGetID0Endpoints());

    }
    @Step("I receive valid HTTP response code 404 Not Found")
    public void HTTPGetID0Response404(){
        restAssuredThat(response ->response.statusCode(404));
    }

    @Step("I didn't received valid data for user details from ID 0")
    public void valiDataID0() {
        restAssuredThat(response -> response.body("id", equalTo(null)));
    }
}
