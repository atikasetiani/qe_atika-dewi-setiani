package starter.StepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.user.*;

public class UserSteps {
    @Steps
    GetAllPosiitif getAllPosiitif;

    @Steps
    GetAllNegatif getAllNegatif;

    @Steps
    PostPositif postPositif;

    @Steps
    PostNegatif_1 postNegatif_1;

    @Steps
    PostNegatif_2 postNegatif_2;

    @Steps
    GetIDPositif getIDPositif;

    @Steps
    GetIDNegatif_1 getIDNegatif_1;

    @Steps
    PutIDPositif putIDPositif;

    @Steps
    PutIDNegatif putIDNegatif;

    @Steps
    DeleteIDPositif deleteIDPositif;

    @Given("I set a GET endpoints")
    public void setGetEndpoints(){
        getAllPosiitif.setGetEndpoints();
    }
    @When("I send HTTP GET request")
    public void getHTTPrequest(){
        getAllPosiitif.getHTTPrequest();
    }
    @Then("I receive a valid HTTP response code 200 OK")
    public void HTTPresponse200(){
        getAllPosiitif.HTTPresponse200();
    }
    @And("I received valid data for all user details")
    public void valiData(){
        getAllPosiitif.valiData();
    }

    @Given("I set the GET endpoint part")
    public void setGetInvalidEndpoints(){
        getAllNegatif.setGetInvalidEndpoints();
    }
    @When("I send a request to the HTTP GET part")
    public void GetPartHTTPrequest(){
        getAllNegatif.GetPartHTTPrequest();
    }
    @Then("I receive a valid HTTP response code 404 Not Found")
    public void HTTPresponse404(){
        getAllNegatif.HTTPresponse404();
    }
    @And("I didn't received valid data for all user details")
    public void dataEmpty(){
        getAllNegatif.dataEmpty();
    }

    @Given("I set POST endpoints")
    public void setPostApiEndpoint(){
        postPositif.setPostApiEndpoint();
    }
    @When("I send POST HTTP request")
    public void sendPostHTTPRequest(){
        postPositif.sendPostHttpRequest();
    }
    @Then("I receive valid HTTP response code 201 OK")
    public void receiveValidHttp201(){
        postPositif.receiveHttpResponseCode201();
    }
    @And("I receive valid data for new user")
    public void validateDataNewUser(){
        postPositif.validateDatanewUser();
    }

    @Given("I set the POST endpoints")
    public void setPostEndpoint(){
        postNegatif_1.setPostEndpoint();
    }
    @When("I send a request to the HTTP POST part")
    public void sendPostRequest(){
        postNegatif_1.sendPostRequest();
    }
    @Then("I receive valid HTTP response code 500 Internal Server Error")
    public void receiveHttpResponseCode500(){
        postNegatif_1.receiveHttpResponseCode500();
    }
    @And("I don't receive valid data for new user")
    public void validateDataUser(){
        postNegatif_1.validateDataUser();
    }

    @Given("I set a POST endpoints")
    public void setPostDataEndpoint(){
        postNegatif_2.setPostDataEndpoint();
    }
    @When("I send request to the HTTP POST part")
    public void sendRequestHTTPPost(){
        postNegatif_2.sendRequestHTTPPost();
    }
    @Then("I receive HTTP response code 500 Internal Server Error")
    public void receiveResponseCode500(){
        postNegatif_2.receiveResponseCode500();
    }
    @And("I don't receive valid data for new user from create new user")
    public void validatePostDataUser(){
        postNegatif_2.validatePostDataUser();
    }

    @Given("I set a GET endpoints by ID 1")
    public void setGetIDEndpoints(){
        getIDPositif.setGetIDEndpoints();
    }
    @When("I send HTTP GET to the request")
    public void getIDHTTPrequest(){
        getIDPositif.getIDHTTPrequest();
    }
    @Then("I receive valid HTTP response code 200 OK")
    public void HTTPGetResponse200OK(){
        getIDPositif.HTTPGetResponse200();
    }
    @And("I received valid data for user details by ID 1")
    public void valiDataID(){
        getIDPositif.valiDataID();
    }

    @Given("I set a GET endpoints by ID 0")
    public void setGetID0Endpoints(){ getIDNegatif_1.setGetID0Endpoints();
    }
    @When("I send HTTP GET the request")
    public void getID0HTTPrequest(){ getIDNegatif_1.getID0HTTPrequest();
    }
    @Then("I receive valid HTTP response code 404 Not Found")
    public void HTTPGetID0Response404(){ getIDNegatif_1.HTTPGetID0Response404();
    }
    @And("I didn't received valid data for user details from ID 0")
    public void valiDataID0(){
        getIDNegatif_1.valiDataID0();
    }

    @Given("I set PUT endpoints")
    public void setPutEndpoint(){
        putIDPositif.setPutEndpoint();
    }
    @When("I send PUT HTTP request")
    public void sendPutHttpRequest(){
        putIDPositif.sendPutHttpRequest();
    }
    @Then("I receive valid HTTP Put response code is 200 OK")
    public void receiveResponseCode200(){
        putIDPositif.receiveResponseCode200();
    }
    @And("I receive valid data for existing user")
    public void validateDataForExistingUser(){
        putIDPositif.ValidateDataForExistingUser();
    }

    @Given("I set a PUT endpoints")
    public void setPutIDEndpoint(){
        putIDNegatif.setPutIDEndpoint();
    }
    @When("I send a PUT HTTP to the request part")
    public void sendPutIDHttpRequest(){
        putIDNegatif.sendPutIDHttpRequest();
    }
    @Then("I receive valid HTTP Put response code is 500 Internal Server Error")
    public void receiveResponseCode500ISE(){
        putIDNegatif.receiveResponseCode500ISE();
    }
    @And("I didn't receive valid data for existing user")
    public void ValidateForExistingUser(){
        putIDNegatif.ValidateForExistingUser();
    }

    @Given("I set DELETE endpoints")
    public void setDeleteEndpoint(){
        deleteIDPositif.setDeleteEndpoint();
    }
    @When("I send DELETE HTTP request")
    public void sendDeleteHttpRequest(){
        deleteIDPositif.sendDeleteHttpRequest();
    }
    @Then("I receive valid DELETE HTTP response code 200 OK")
    public void validHttpresponseCode200(){
        deleteIDPositif.validHttpresponseCode200();
    }

}
