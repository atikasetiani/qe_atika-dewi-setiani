package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.notNullValue;


public class GetAllNegatif {
    protected static String url = "https://jsonplaceholder.typicode.com/";
    @Step("I set the GET endpoint part")
    public String setGetInvalidEndpoints(){
        return url + "post";

    }
    @Step("I send a request to the HTTP GET part")
    public void GetPartHTTPrequest(){
        SerenityRest.given()
                .when()
                .get(setGetInvalidEndpoints())
                .getBody()
                .asString();
    }

    @Step("I receive a valid HTTP response code 404 Not Found")
    public void HTTPresponse404(){
        restAssuredThat(response ->response.statusCode(404));
        restAssuredThat(response -> response.body("$", notNullValue()));
    }

    @Step("I didn't received valid data for all user details")
    public void dataEmpty() {
        restAssuredThat(response -> response.body("$", notNullValue()));
    }
}
