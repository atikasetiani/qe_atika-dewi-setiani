package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class PutIDPositif {

    protected String url = "https://jsonplaceholder.typicode.com/";

    @Step("I set PUT endpoints")
    public String setPutEndpoint(){
        return url + "posts/1";
    }

    @Step("I send PUT HTTP request")
    public void sendPutHttpRequest(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("body", "Ini adalah isi update post yang baru");
        requestBody.put("title", "Update Post Baru");
        requestBody.put("userId", "1");

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).put(setPutEndpoint());
    }

    @Step("I receive valid HTTP Put response code is 200 OK")
    public void receiveResponseCode200(){
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("I receive valid data for existing user")
    public void ValidateDataForExistingUser(){
        restAssuredThat(response -> response.body("'body'", equalTo("Ini adalah isi update post yang baru")));
        restAssuredThat(response -> response.body("'title'", equalTo("Update Post Baru")));
        restAssuredThat(response -> response.body("'userId'", equalTo("1")));
    }

}
