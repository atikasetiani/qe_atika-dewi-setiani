package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class PostNegatif_1 {
    protected String url = "https://jsonplaceholder.typicode.com/";

    @Step("I set the POST endpoints")
    public String setPostEndpoint(){
        return url + "posts";
    }

    @Step("I send a request to the HTTP POST part")
    public void sendPostRequest(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("body", notNullValue());
        requestBody.put("title", notNullValue());

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).post(setPostEndpoint());
    }

    @Step("I receive valid HTTP response code 500 Internal Server Error")
    public void receiveHttpResponseCode500(){
        restAssuredThat(response -> response.statusCode(500));
    }

    @Step("I don't receive valid data for new user")
    public void validateDataUser(){
        restAssuredThat(response -> response.body("'body'", notNullValue()));
        restAssuredThat(response -> response.body("'title'", notNullValue()));
    }
}
