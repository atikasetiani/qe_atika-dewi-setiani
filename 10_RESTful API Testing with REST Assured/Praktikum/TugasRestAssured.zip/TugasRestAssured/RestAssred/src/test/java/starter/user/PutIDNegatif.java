package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class PutIDNegatif {
    protected String url = "https://jsonplaceholder.typicode.com/";

    @Step("I set a PUT endpoints")
    public String setPutIDEndpoint(){
        return url + "posts/1";
    }

    @Step("I send a PUT HTTP to the request part")
    public void sendPutIDHttpRequest(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("body", "Ini adalah isi update post yang baru");
        requestBody.put("title", "Update Post Baru");
        requestBody.put("userId", notNullValue());

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).put(setPutIDEndpoint());
    }

    @Step("I receive valid HTTP Put response code is 500 Internal Server Error")
    public void receiveResponseCode500ISE(){
        restAssuredThat(response -> response.statusCode(500));
    }

    @Step("I didn't receive valid data for existing user")
    public void ValidateForExistingUser(){
        restAssuredThat(response -> response.body("'userId'", notNullValue()));}
}
