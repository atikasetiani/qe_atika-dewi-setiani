package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class PostNegatif_2 {
    protected String url = "https://jsonplaceholder.typicode.com/";

    @Step("I set a POST endpoints")
    public String setPostDataEndpoint(){
        return url + "posts";
    }

    @Step("I send request to the HTTP POST part")
    public void sendRequestHTTPPost(){
        JSONObject requestBody = new JSONObject();
        requestBody.put("userId", notNullValue());

        SerenityRest.given().header("Content-Type", "application/json").body(requestBody.toJSONString()).post(setPostDataEndpoint());
    }

    @Step("I receive HTTP response code 500 Internal Server Error")
    public void receiveResponseCode500(){
        restAssuredThat(response -> response.statusCode(500));
    }

    @Step("I don't receive valid data for new user from create new user")
    public void validatePostDataUser(){
        restAssuredThat(response -> response.body("'userId'", notNullValue()));
    }
}
