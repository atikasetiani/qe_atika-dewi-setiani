package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class GetIDPositif {
    protected static String url = "https://jsonplaceholder.typicode.com/";
    @Step("I set a GET endpoints by ID 1")
    public String setGetIDEndpoints(){
        return url + "posts/1";

    }
    @Step("I send HTTP GET to the request")
    public void getIDHTTPrequest(){
        SerenityRest.given()
                .when()
                .get(setGetIDEndpoints());

    }
    @Step("I receive valid HTTP response code 200 OK")
    public void HTTPGetResponse200(){
        restAssuredThat(response ->response.statusCode(200));
    }

    @Step("I received valid data for user details by ID 1")
    public void valiDataID() {
        restAssuredThat(response -> response.body("id", equalTo(1)));
    }
}
